import { useEffect, useState, useRef } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";

const API_KEY = process.env.REACT_APP_API_KEY; // Usar variable de entorno

export default function App() {
  const [games, setGames] = useState([]);
  const [history, setHistory] = useState({});
  const [notifications, setNotifications] = useState([]);
  const [darkMode, setDarkMode] = useState(true);
  const previousKillsRef = useRef({});
  const previousRoshanRef = useRef({});

  useEffect(() => {
    const fetchGames = async () => {
      const res = await fetch(
        `https://api.steampowered.com/IDOTA2Match_570/GetLiveLeagueGames/v1/?key=${API_KEY}`
      );
      const data = await res.json();
      const liveGames = data.result.games || [];
      setGames(liveGames);

      const newHistory = { ...history };
      const newNotifications = [];
      const prevKills = { ...previousKillsRef.current };
      const prevRoshan = { ...previousRoshanRef.current };

      liveGames.forEach((game) => {
        const id = game.match_id;
        const duration = Math.floor(game.scoreboard?.duration || 0);
        const rad = game.scoreboard?.radiant?.net_worth ?? null;
        const dire = game.scoreboard?.dire?.net_worth ?? null;
        if (rad !== null && dire !== null) {
          const diff = rad - dire;
          if (!newHistory[id]) newHistory[id] = [];
          newHistory[id].push({ time: duration, diff });
        }

        // Detectar team wipe o actividad
        const radiantPlayers = game.scoreboard?.radiant?.players || [];
        const direPlayers = game.scoreboard?.dire?.players || [];

        const totalRadiantKills = radiantPlayers.reduce((sum, p) => sum + p.kills, 0);
        const totalDireKills = direPlayers.reduce((sum, p) => sum + p.kills, 0);

        const previous = prevKills[id] || { radiant: 0, dire: 0 };

        if (totalRadiantKills > previous.radiant + 4) {
          newNotifications.push(`⚔️ Team wipe a Dire en la partida ${id}`);
        } else if (totalDireKills > previous.dire + 4) {
          newNotifications.push(`⚔️ Team wipe a Radiant en la partida ${id}`);
        } else if (totalRadiantKills > previous.radiant || totalDireKills > previous.dire) {
          newNotifications.push(`🎯 Pelea en partida ${id}`);
        }

        prevKills[id] = {
          radiant: totalRadiantKills,
          dire: totalDireKills,
        };

        // Detectar Roshan kill
        const roshanStatus = game.scoreboard?.roshan_respawn_timer ?? null;
        if (roshanStatus === 0 && prevRoshan[id] !== 0) {
          newNotifications.push(`🧊 Roshan asesinado en partida ${id}`);
        }
        prevRoshan[id] = roshanStatus;

        // Detectar mega creeps
        const radiantMega = game.scoreboard?.dire?.mega_creeps ?? false;
        const direMega = game.scoreboard?.radiant?.mega_creeps ?? false;

        if (radiantMega) {
          newNotifications.push(`🚨 Radiant tiene mega creeps en partida ${id}`);
        }
        if (direMega) {
          newNotifications.push(`🚨 Dire tiene mega creeps en partida ${id}`);
        }
      });

      previousKillsRef.current = prevKills;
      previousRoshanRef.current = prevRoshan;
      setNotifications((prev) => [...newNotifications, ...prev].slice(0, 5));
      setHistory(newHistory);
    };

    fetchGames();
    const interval = setInterval(fetchGames, 10000);
    return () => clearInterval(interval);
  }, [history]);

  return (
    <div className={`${darkMode ? "bg-gray-950 text-white" : "bg-white text-black"} min-h-screen p-6`}>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-center w-full">Dota 2 Live Pro Matches</h1>
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="absolute right-6 bg-gray-700 text-white px-4 py-1 rounded hover:bg-gray-600"
        >
          {darkMode ? "☀️ Modo Claro" : "🌙 Modo Oscuro"}
        </button>
      </div>

      {notifications.length > 0 && (
        <div className="mb-6 p-4 bg-gray-800 rounded-xl shadow text-sm">
          <h2 className="font-bold mb-2">🔔 Notificaciones recientes:</h2>
          <ul className="list-disc pl-5 space-y-1">
            {notifications.map((note, index) => (
              <li key={index}>{note}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {games.map((game) => {
          const matchHistory = history[game.match_id] || [];
          const picksBans = game.picks_bans || [];
          const radiantPlayers = game.scoreboard?.radiant?.players || [];
          const direPlayers = game.scoreboard?.dire?.players || [];

          return (
            <div key={game.match_id} className="bg-gray-900 rounded p-4">
              <h2 className="text-xl font-semibold">
                {game.radiant_team?.team_name || "Radiant"} vs {game.dire_team?.team_name || "Dire"}
              </h2>
              <p>📍 Duration: {Math.floor(game.scoreboard?.duration || 0)}s</p>
              <p>
                🔴 Radiant: {game.scoreboard?.radiant?.score ?? "-"} | 💰 Net Worth: {game.scoreboard?.radiant?.net_worth ?? "-"}
              </p>
              <p>
                🔵 Dire: {game.scoreboard?.dire?.score ?? "-"} | 💰 Net Worth: {game.scoreboard?.dire?.net_worth ?? "-"}
              </p>

              {picksBans.length > 0 && (
                <div>
                  <p className="font-semibold">🎯 Draft:</p>
                  <ul className="text-sm space-y-1">
                    {picksBans.map((pb, index) => (
                      <li key={index}>
                        {pb.is_pick ? "✅ Pick" : "⛔ Ban"} - {pb.team === 0 ? "Radiant" : "Dire"} - Hero ID: {pb.hero_id}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div>
                <p className="font-semibold">🧙 Radiant Players:</p>
                <ul className="text-sm">
                  {radiantPlayers.map((player, index) => (
                    <li key={index}>Hero ID: {player.hero_id} | K/D/A: {player.kills}/{player.deaths}/{player.assists}</li>
                  ))}
                </ul>
              </div>

              <div>
                <p className="font-semibold">💀 Dire Players:</p>
                <ul className="text-sm">
                  {direPlayers.map((player, index) => (
                    <li key={index}>Hero ID: {player.hero_id} | K/D/A: {player.kills}/{player.deaths}/{player.assists}</li>
                  ))}
                </ul>
              </div>

              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={matchHistory}>
                    <XAxis dataKey="time" tick={{ fill: "white" }} />
                    <YAxis tick={{ fill: "white" }} domain={["auto", "auto"]} />
                    <Tooltip />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Line
                      type="monotone"
                      dataKey="diff"
                      stroke="#00FF88"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}