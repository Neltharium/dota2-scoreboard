# Dota 2 Live Scoreboard

Proyecto React para mostrar partidas profesionales de Dota 2 en vivo con notificaciones y gráficos de net worth.

## Cómo usar

1. Clona el repositorio
2. Ejecuta `npm install`
3. Crea un archivo `.env` y añade tu clave API de Steam:

```
REACT_APP_API_KEY=tu_clave_aqui
```

4. Ejecuta `npm start` para ver la app en desarrollo

5. Para producción, construye con `npm run build`